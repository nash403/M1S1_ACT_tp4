package travellingSalemansProblem;

import java.util.Random;
import java.io.*;

import classesPb.*;

public class CertificatTSP implements Certificat{
// A completer
	

}
